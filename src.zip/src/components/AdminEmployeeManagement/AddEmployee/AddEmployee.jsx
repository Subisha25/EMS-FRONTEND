// // import React from 'react';

// // const AddEmployeeForm = () => {
// //   return (
// //     <div className="max-w-6xl mx-auto p-6 bg-white shadow-2xl rounded-2xl mt-10 mb-10">
// //       <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">Add Employee</h2>
// //       <form className="grid grid-cols-1 md:grid-cols-2 gap-6">
// //         {/* Emp ID */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">Emp ID</label>
// //           <input type="text" placeholder="Enter your EmpId" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>

// //         {/* First & Last Name */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">First Name</label>
// //           <input type="text" placeholder="Enter your First Name" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">Last Name</label>
// //           <input type="text" placeholder="Enter your Last Name" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>

// //         {/* Department */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">Department</label>
// //           <select className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
// //             <option>--select--</option>
// //             <option>HR</option>
// //             <option>Development</option>
// //             <option>Marketing</option>
// //           </select>
// //         </div>

// //         {/* Email */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">Email ID</label>
// //           <input type="email" placeholder="Enter your Email ID" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>

// //         {/* Mobile No */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">Mobile No</label>
// //           <input type="text" placeholder="Enter your Mobile No" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>

// //         {/* Country */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">Country</label>
// //           <input type="text" placeholder="Enter your Country" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>

// //         {/* State */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">State</label>
// //           <input type="text" placeholder="Enter your State" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>

// //         {/* City */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">City</label>
// //           <input type="text" placeholder="Enter your City" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>

// //         {/* DOB */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">DOB</label>
// //           <input type="date" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>

// //         {/* DOJ */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">Date of Joining</label>
// //           <input type="date" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>

// //         {/* Photo */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">Photo</label>
// //           <input type="file" className="w-full p-2 border rounded-lg" />
// //         </div>

// //         {/* Address */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">Address</label>
// //           <textarea placeholder="Enter your Address" rows="3" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
// //         </div>

// //         {/* Password */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">Password</label>
// //           <input type="password" placeholder="Enter your Password" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>

// //         {/* Confirm Password */}
// //         <div>
// //           <label className="block mb-1 font-medium text-gray-700">Confirm Password</label>
// //           <input type="password" placeholder="Confirm Password" className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
// //         </div>
// //       </form>

// //       {/* Submit Button */}
// //       <div className="mt-8 text-center">
// //         <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3 rounded-lg transition duration-300">
// //           Submit
// //         </button>
// //       </div>
// //     </div>
// //   );
// // };

// // export default AddEmployeeForm;


// import React from 'react';
// import { useForm } from 'react-hook-form';

// const AddEmployeeForm = () => {
//   const {
//     register,
//     handleSubmit,
//     watch,
//     formState: { errors },
//   } = useForm();

//   const onSubmit = (data) => {
//     console.log('Form Data:', data);
//     alert("Form submitted successfully!");
//   };

//   const password = watch("password");

//   return (
//     <div className="max-w-6xl mx-auto p-6 bg-white shadow-2xl rounded-2xl mt-10 mb-10">
//       <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">Add Employee</h2>
//       <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-6">

//         {/* Emp ID */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">Emp ID</label>
//           <input
//             type="text"
//             {...register("empId", { required: "Emp ID is required" })}
//             placeholder="Enter your EmpId"
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.empId && <p className="text-red-600">{errors.empId.message}</p>}
//         </div>

//         {/* First Name */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">First Name</label>
//           <input
//             type="text"
//             {...register("firstName", { required: "First Name is required" })}
//             placeholder="Enter your First Name"
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.firstName && <p className="text-red-600">{errors.firstName.message}</p>}
//         </div>

//         {/* Last Name */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">Last Name</label>
//           <input
//             type="text"
//             {...register("lastName", { required: "Last Name is required" })}
//             placeholder="Enter your Last Name"
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.lastName && <p className="text-red-600">{errors.lastName.message}</p>}
//         </div>

//         {/* Department */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">Department</label>
//           <select
//             {...register("department", { required: "Department is required" })}
//             className="w-full p-3 border rounded-lg"
//           >
//             <option value="">--select--</option>
//             <option value="HR">HR</option>
//             <option value="Development">Development</option>
//             <option value="Marketing">Marketing</option>
//           </select>
//           {errors.department && <p className="text-red-600">{errors.department.message}</p>}
//         </div>

//         {/* Email */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">Email ID</label>
//           <input
//             type="email"
//             {...register("email", {
//               required: "Email is required",
//               pattern: {
//                 value: /^[a-zA-Z0-9._%+-]+@gmail\.com$/,
//                 message: "Email must be a valid @gmail.com"
//               }
//             })}
//             placeholder="Enter your Email ID"
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.email && <p className="text-red-600">{errors.email.message}</p>}
//         </div>

//         {/* Mobile No */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">Mobile No</label>
//           <input
//             type="text"
//             {...register("mobile", {
//               required: "Mobile number is required",
//               pattern: {
//                 value: /^[0-9]{10}$/,
//                 message: "Mobile number must be 10 digits"
//               }
//             })}
//             placeholder="Enter your Mobile No"
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.mobile && <p className="text-red-600">{errors.mobile.message}</p>}
//         </div>

//         {/* Country */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">Country</label>
//           <input
//             type="text"
//             {...register("country", { required: "Country is required" })}
//             placeholder="Enter your Country"
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.country && <p className="text-red-600">{errors.country.message}</p>}
//         </div>

//         {/* State */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">State</label>
//           <input
//             type="text"
//             {...register("state", { required: "State is required" })}
//             placeholder="Enter your State"
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.state && <p className="text-red-600">{errors.state.message}</p>}
//         </div>

//         {/* City */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">City</label>
//           <input
//             type="text"
//             {...register("city", { required: "City is required" })}
//             placeholder="Enter your City"
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.city && <p className="text-red-600">{errors.city.message}</p>}
//         </div>

//         {/* DOB */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">DOB</label>
//           <input
//             type="date"
//             {...register("dob", { required: "Date of Birth is required" })}
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.dob && <p className="text-red-600">{errors.dob.message}</p>}
//         </div>

//         {/* DOJ */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">Date of Joining</label>
//           <input
//             type="date"
//             {...register("doj", { required: "Date of Joining is required" })}
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.doj && <p className="text-red-600">{errors.doj.message}</p>}
//         </div>

//         {/* Photo */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">Photo</label>
//           <input
//             type="file"
//             {...register("photo", { required: "Photo is required" })}
//             className="w-full p-2 border rounded-lg"
//           />
//           {errors.photo && <p className="text-red-600">{errors.photo.message}</p>}
//         </div>

//         {/* Address */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">Address</label>
//           <textarea
//             {...register("address", { required: "Address is required" })}
//             placeholder="Enter your Address"
//             rows="3"
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.address && <p className="text-red-600">{errors.address.message}</p>}
//         </div>

//         {/* Password */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">Password</label>
//           <input
//             type="password"
//             {...register("password", {
//               required: "Password is required",
//               minLength: {
//                 value: 6,
//                 message: "Password must be at least 6 characters"
//               }
//             })}
//             placeholder="Enter your Password"
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.password && <p className="text-red-600">{errors.password.message}</p>}
//         </div>

//         {/* Confirm Password */}
//         <div>
//           <label className="block mb-1 font-medium text-gray-700">Confirm Password</label>
//           <input
//             type="password"
//             {...register("confirmPassword", {
//               required: "Confirm Password is required",
//               validate: value => value === password || "Passwords do not match"
//             })}
//             placeholder="Confirm Password"
//             className="w-full p-3 border rounded-lg"
//           />
//           {errors.confirmPassword && <p className="text-red-600">{errors.confirmPassword.message}</p>}
//         </div>
//       </form>

//       {/* Submit Button */}
//       <div className="mt-8 text-center">
//         <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3 rounded-lg transition duration-300">
//           Submit
//         </button>
//       </div>
//     </div>
//   );
// };

// export default AddEmployeeForm;


import React from 'react';
import { useForm } from 'react-hook-form';

const AddEmployeeForm = () => {
  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm();

  const password = watch("password");

  const onSubmit = async (data) => {
    try {
      const formData = new FormData();

      formData.append("emp_id", data.empId);
      formData.append("first_name", data.firstName);
      formData.append("last_name", data.lastName);
      formData.append("department", data.department);
      formData.append("email", data.email);
      formData.append("mobile", data.mobile);
      formData.append("country", data.country);
      formData.append("state", data.state);
      formData.append("city", data.city);
      formData.append("dob", data.dob);
      formData.append("doj", data.doj);
      formData.append("address", data.address);
      formData.append("password", data.password);
      formData.append("photo", data.photo[0]); // handle file upload

      const response = await fetch("http://localhost/ems-backend/api/employee/add.php", {
        method: "POST",
        body: formData,
      });

      const result = await response.json();

      if (result.status) {
        alert("Employee added successfully!");
        reset();
      } else {
        alert("Failed to add employee: " + result.message);
      }

    } catch (error) {
      console.error("Error submitting form:", error);
      alert("Error submitting form.");
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 bg-white shadow-2xl rounded-2xl mt-10 mb-10">
      <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">Add Employee</h2>
      <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* Emp ID */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">Emp ID</label>
          <input
            type="text"
            {...register("empId", { required: "Emp ID is required" })}
            placeholder="Enter your EmpId"
            className="w-full p-3 border rounded-lg"
          />
          {errors.empId && <p className="text-red-600">{errors.empId.message}</p>}
        </div>

        {/* First Name */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">First Name</label>
          <input
            type="text"
            {...register("firstName", { required: "First Name is required" })}
            placeholder="Enter your First Name"
            className="w-full p-3 border rounded-lg"
          />
          {errors.firstName && <p className="text-red-600">{errors.firstName.message}</p>}
        </div>

        {/* Last Name */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">Last Name</label>
          <input
            type="text"
            {...register("lastName", { required: "Last Name is required" })}
            placeholder="Enter your Last Name"
            className="w-full p-3 border rounded-lg"
          />
          {errors.lastName && <p className="text-red-600">{errors.lastName.message}</p>}
        </div>

        {/* Department */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">Department</label>
          <select
            {...register("department", { required: "Department is required" })}
            className="w-full p-3 border rounded-lg"
          >
            <option value="">--select--</option>
            <option value="HR">HR</option>
            <option value="Development">Development</option>
            <option value="Marketing">Marketing</option>
          </select>
          {errors.department && <p className="text-red-600">{errors.department.message}</p>}
        </div>

        {/* Email */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">Email ID</label>
          <input
            type="email"
            {...register("email", {
              required: "Email is required",
              pattern: {
                value: /^[a-zA-Z0-9._%+-]+@gmail\.com$/,
                message: "Email must be a valid @gmail.com"
              }
            })}
            placeholder="Enter your Email ID"
            className="w-full p-3 border rounded-lg"
          />
          {errors.email && <p className="text-red-600">{errors.email.message}</p>}
        </div>

        {/* Mobile No */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">Mobile No</label>
          <input
            type="text"
            {...register("mobile", {
              required: "Mobile number is required",
              pattern: {
                value: /^[0-9]{10}$/,
                message: "Mobile number must be 10 digits"
              }
            })}
            placeholder="Enter your Mobile No"
            className="w-full p-3 border rounded-lg"
          />
          {errors.mobile && <p className="text-red-600">{errors.mobile.message}</p>}
        </div>

        {/* Country */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">Country</label>
          <input
            type="text"
            {...register("country", { required: "Country is required" })}
            placeholder="Enter your Country"
            className="w-full p-3 border rounded-lg"
          />
          {errors.country && <p className="text-red-600">{errors.country.message}</p>}
        </div>

        {/* State */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">State</label>
          <input
            type="text"
            {...register("state", { required: "State is required" })}
            placeholder="Enter your State"
            className="w-full p-3 border rounded-lg"
          />
          {errors.state && <p className="text-red-600">{errors.state.message}</p>}
        </div>

        {/* City */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">City</label>
          <input
            type="text"
            {...register("city", { required: "City is required" })}
            placeholder="Enter your City"
            className="w-full p-3 border rounded-lg"
          />
          {errors.city && <p className="text-red-600">{errors.city.message}</p>}
        </div>

        {/* DOB */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">DOB</label>
          <input
            type="date"
            {...register("dob", { required: "Date of Birth is required" })}
            className="w-full p-3 border rounded-lg"
          />
          {errors.dob && <p className="text-red-600">{errors.dob.message}</p>}
        </div>

        {/* DOJ */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">Date of Joining</label>
          <input
            type="date"
            {...register("doj", { required: "Date of Joining is required" })}
            className="w-full p-3 border rounded-lg"
          />
          {errors.doj && <p className="text-red-600">{errors.doj.message}</p>}
        </div>

        {/* Photo */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">Photo</label>
          <input
            type="file"
            {...register("photo", { required: "Photo is required" })}
            className="w-full p-2 border rounded-lg"
          />
          {errors.photo && <p className="text-red-600">{errors.photo.message}</p>}
        </div>

        {/* Address */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">Address</label>
          <textarea
            {...register("address", { required: "Address is required" })}
            placeholder="Enter your Address"
            rows="3"
            className="w-full p-3 border rounded-lg"
          />
          {errors.address && <p className="text-red-600">{errors.address.message}</p>}
        </div>

        {/* Password */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">Password</label>
          <input
            type="password"
            {...register("password", {
              required: "Password is required",
              minLength: {
                value: 6,
                message: "Password must be at least 6 characters"
              }
            })}
            placeholder="Enter your Password"
            className="w-full p-3 border rounded-lg"
          />
          {errors.password && <p className="text-red-600">{errors.password.message}</p>}
        </div>

        {/* Confirm Password */}
        <div>
          <label className="block mb-1 font-medium text-gray-700">Confirm Password</label>
          <input
            type="password"
            {...register("confirmPassword", {
              required: "Confirm Password is required",
              validate: value => value === password || "Passwords do not match"
            })}
            placeholder="Confirm Password"
            className="w-full p-3 border rounded-lg"
          />
          {errors.confirmPassword && <p className="text-red-600">{errors.confirmPassword.message}</p>}
        </div>
      </form>

      {/* Submit Button */}
      <div className="mt-8 text-center">
        <button type="submit" onClick={handleSubmit(onSubmit)} className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3 rounded-lg transition duration-300">
          Submit
        </button>
      </div>
    </div>
  );
};

export default AddEmployeeForm;
